const productModel = require("../models/products.model");

exports.getHome = (req, res, next) => {
    // get all products
    // render home page
    let products = productModel.getAllProducts().then((products) => {
        res.render("index", {
            products: products
        });
    });
};
